module.exports = {
    "env": {
        "browser": true,
        "commonjs": true,
        "es6": true
    },
    "extends": "airbnb-base",
    "globals": {
        "Atomics": "readonly",
        "SharedArrayBuffer": "readonly"
    },
    "parserOptions": {
        "ecmaVersion": 2018
    },
    "rules": {
        "no-plusplus": 0,
        "no-console": 1,
        "no-use-before-define": 0,
        "consistent-return": 1,
        "no-continue": 0,
        "no-loop-func": 0,
    }
};